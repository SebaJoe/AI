import spacy

nlp = spacy.load("en_core_web_sm")
doc = nlp(u"If you want to buy a sexy, cool, accessory-available mp3 palyer you can choose iPod.")
for token in doc:
     print(token.text, token.dep_, token.head.text, token.head.pos_,
            [child for child in token.children])
