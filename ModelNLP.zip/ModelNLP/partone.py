import spacy, json
#from xml.dom import minidom
import xml.etree.ElementTree as et
#initializing spacy
data = "" #this is where the filename goes
nlp = spacy.load('en_core_web_sm', disable=['ner'])
#opinions files
f = open("negative-words.txt", 'r')
t = open("positive-words.txt", 'r')
#Good -> mod -> screen
def R1_one(text, known):
    doc = nlp(u""+text)
    for token in doc:
        if token.text == known and token.dep_ == "amod":
            for tok in doc:
                if token in tok.children:
                    return tok.text
#best -> mod -> player <- subj <- iPod
def R1_two(text, known):
    doc = nlp(u""+text)
    for token in doc:
        if token.text == known and token.dep_ == 'amod':
            for tok in doc:
                if tok.dep_ == 'nsubj':
                    return tok.text    
#R1_1 but returning good instead of screen
def R2_one(text, known):
    doc = nlp(u""+text)
    for token in doc:
        if token.text == known:
            for child in token.children:
                if child.dep_ == 'amod':
                    return child.text
#R1_2 but returning best instead of iPod
def R2_two(text, known):
    doc = nlp(u""+text)
    for token in doc:
        if token.text == known and token.dep_ == 'nsubj':
            for tok in doc:
                if tok.dep_ == 'attr':
                    return R2_one(text, tok.text)
#video -> conj -> audio
def R3_one(text, known):
    doc = nlp(u""+text)
    for token in doc:
        if token.dep_ == 'pobj' and token.text == known:
            for tok in doc:
                if tok.dep_ == 'conj' and tok in token.children:
                    return tok.text
#lens -> obj -> has <- subj <- G3
def R3_two(text, known):
    doc = nlp(u""+text)
    for token in doc:
        #print(token.text, token.head.text)
        if token.text == known:
            for tok in doc:
                if tok.dep_ == 'nsubj' and tok.head.text == token.head.text:
                    return tok.text
#easy -> conj -> amazing    
def R4_one(text, known):
    doc = nlp(u""+text)
    for token in doc:
        if token.text == known and token.dep_ == 'acomp':
            for tok in doc:
                if tok in token.children and tok.dep_ == "conj":
                    return tok.text
#sexy -> mode -> player <- mod <- cool    
def R4_two(text, known):
    doc = nlp(u""+text)
    for token in doc:
        if token.text == known and token.dep_ == 'amod':
            token_header = token.head.text
            for tok in doc:
                if tok.dep_ == 'amod' and tok.head.text == token_header:
                    return tok.text    
#print(R4_two("If you want to buy a sexy, cool, accessory-available mp3 player, you can choose iPod.","sexy"))
#This is the main function
def main():
    #starting inputs
    #O_ex = f.readlines() + t.readlines()
    O_ex = ["happy", "great", "disappointing"]
    for i in range(0,len(O_ex)):
        O_ex[i] = O_ex[i].strip("\n")
    print(O_ex[0])
    feat = []
    tree = et.parse('ABSA16_Laptops_Train_SB1_v2.xml')
    root = tree.getroot()
    print('Processing reviews...')
    while True:
        f_i = []
        O_i = []
        for review in root.findall("Review/sentences/sentence"):
            #print(review)
            s = review.find("text").text
            #print(s)
            feet1_1 = "" #extracted features with R1_1
            feet1_2 = "" #feat for R1_2
            op4_1 = ""
            op4_2 = ""
            for word in s.split():
                if (word in O_ex):
                    feet1_1 = R1_one(s, word)
                    feet1_2 = R1_two(s, word)
                    if (feet1_1 not in feat and feet1_1 not in f_i) and feet1_1 != None:
                        f_i.append(feet1_1)
                    if (feet1_2 not in feat and feet1_2 not in f_i) and feet1_2 != None:
                        f_i.append(feet1_2)
                    op4_1 = R4_one(s, word)
                    op4_2 = R4_two(s, word)
                    if (op4_1 not in O_ex and op4_1 not in O_i) and op4_1 != None:
                        O_i.append(op4_1)
                    if (op4_2 not in O_ex and op4_2 not in O_i) and op4_2 != None:
                        O_i.append(op4_2)
        feat = feat + f_i
        O_ex = O_ex + O_i
        fprime = []
        oprime = []
        for review in root.findall("Review/sentences/sentence"):
            s = review.find("text").text
            feet3_1 = ""
            feet3_2 = ""
            op2_1 = ""
            op2_2 = ""
            for word in s.split():
                if word in feat:
                    feet3_1 = R3_one(s, word)
                    feet3_2 = R3_two(s, word)
                    if (feet3_1 not in feat and feet3_1 not in fprime) and feet3_1 != None:
                        fprime.append(feet3_1)
                    if (feet3_2 not in feat and feet3_2 not in fprime) and feet3_2 != None:
                        fprime.append(feet3_2)
                    op2_1 = R2_one(s, word)
                    op2_2 = R2_two(s, word)
                    if (op2_1 not in O_ex and op2_1 not in oprime) and op2_1 != None:
                        oprime.append(op2_1)
                    if (op2_2 not in O_ex and op2_2 not in oprime) and op2_2 != None:
                        oprime.append(op2_2)
        f_i = f_i + fprime
        O_i = O_i + oprime
        feat = feat + fprime
        O_ex = O_ex + oprime
        print([child for child in f_i])
        if len(f_i) == 0 and len(O_i) == 0:
            break
    print([child for child in feat])
    print([child for child in O_ex])
main()
